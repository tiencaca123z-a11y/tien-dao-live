# ☯ Tiên Đạo Truyền Kỳ - bản game tương tác offline

Bản game web tu tiên với giao diện livestream, bảng xếp hạng, tu vi/cảnh giới, linh thạch, công pháp, boss và lưu tiến trình. Đây là **demo offline** với sự kiện mô phỏng, không kết nối TikTok LIVE hay quà thật.

## Yêu cầu
- Windows 10/11, VS Code, Bun. Python + uv là tùy chọn để chạy bộ mô phỏng.

## Khởi động game
1. Giải nén ZIP.
2. Trong VS Code mở thư mục `tien-dao-live-demo`.
3. Vào Terminal (PowerShell) chạy: `bun run start`
4. Mở trình duyệt: http://localhost:3000
5. Nhập tên và bấm các nút mô phỏng.

Nếu chưa cài Bun: `powershell -c "irm bun.sh/install.ps1 | iex"`, rồi mở lại Terminal.

## Sử dụng Python + uv để tạo sự kiện tự động
Mở Terminal **thứ hai** trong cùng thư mục (giữ server Bun chạy ở Terminal thứ nhất):
```
uv python install 3.12
uv run --python 3.12 simulator/main.py
```
Không cần tải thêm thư viện Python, vì script chỉ dùng thư viện chuẩn. Dừng bằng Ctrl+C.

## Quy tắc game
- Gia nhập: tạo nhân vật
- 10 tim mô phỏng: +20 × cấp công pháp tu vi
- Bình luận tu luyện: +10 × cấp công pháp tu vi
- Quà mô phỏng: +20 linh thạch mỗi đơn vị
- Đánh boss: gây (10 × công pháp + 5 × cảnh giới) sát thương. Người ra đòn kết liễu được thưởng linh thạch.
- Đột phá: tiêu hao 100 × (cảnh giới + 1)² tu vi.
- Nâng công pháp: tiêu hao (cấp công pháp × 50) linh thạch.

## Dữ liệu
File `save.json` được Bun tạo tự động khi chơi. Nút **Đặt lại** xóa dữ liệu của bản demo.

## Giới hạn và bảo mật
- Chạy trên `localhost`, không công khai server trực tiếp ra Internet.
- Endpoint mô phỏng `/api/event` không có xác thực, chỉ phục vụ thử nghiệm cục bộ.
- Không kết nối trực tiếp TikTok, không xử lý quà hoặc tiền thật, không có đăng nhập.
- TikTok LIVE chỉ dành cho tài khoản đủ điều kiện và yêu cầu tuổi tối thiểu theo chính sách của TikTok.
