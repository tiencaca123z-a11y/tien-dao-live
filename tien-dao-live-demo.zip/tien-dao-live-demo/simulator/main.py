"""Giả lập các tương tác của người xem để thử game khi không LIVE."""
import json
import random
import time
import urllib.request

URL = 'http://localhost:3000/api/event'
names = ['Tiểu Minh', 'Bạch Hồ', 'Thanh Vân', 'Kiếm Khách', 'Tiên Nữ', 'Vô Cực']
kinds = ['join', 'heart', 'comment', 'gift', 'fight', 'breakthrough', 'upgrade']
print('☯ Bắt đầu sự kiện mô phỏng. Ctrl+C để dừng.')
try:
    while True:
        event = {'name': random.choice(names), 'kind': random.choices(kinds, weights=[1, 5, 3, 1, 4, 1, 1])[0]}
        event['amount'] = random.randint(1, 5) if event['kind'] == 'heart' else 1
        payload = json.dumps(event).encode('utf-8')
        req = urllib.request.Request(URL, payload, {'Content-Type': 'application/json'}, method='POST')
        try:
            with urllib.request.urlopen(req, timeout=3) as response:
                print(event, response.status)
        except Exception as error:
            print('Không kết nối được game. Mở Bun trước:', error)
        time.sleep(1.5)
except KeyboardInterrupt:
    print('\nĐã dừng mô phỏng.')
