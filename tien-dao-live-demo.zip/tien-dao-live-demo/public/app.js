const $ = id => document.getElementById(id);
const escapeHtml = s => String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let current = {players:[],events:[],boss:{hp:500,maxHp:500,level:1},totalHearts:0,realms:[]};
function draw(s){current=s;$('bosslevel').textContent='Boss tầng '+s.boss.level;$('bossbar').style.width=Math.max(0,s.boss.hp/s.boss.maxHp*100)+'%';$('bosslabel').textContent=s.boss.hp+' / '+s.boss.maxHp+' HP';$('hearts').textContent=s.totalHearts.toLocaleString('vi-VN');$('count').textContent=s.players.length;
$('ranking').innerHTML=s.players.length?s.players.slice(0,15).map((p,i)=>`<div class="rank"><div class="row"><span>${['🥇','🥈','🥉'][i]||'☯'} <b>${escapeHtml(p.name)}</b></span><strong>${escapeHtml(s.realms[p.realm]||'Chân Tiên')}</strong></div><small>✨ ${p.xp} tu vi • 💎 ${p.stones} linh thạch • 📜 Công pháp ${p.power}</small></div>`).join(''):'<p class="dim">Chưa có đạo hữu</p>';
$('events').innerHTML=s.events.length?s.events.map(e=>`<div class="event"><time>${escapeHtml(e.at)}</time><b>${escapeHtml(e.name)}</b>: ${escapeHtml(e.kind)} ${e.amount?'('+e.amount+')':''}</div>`).join(''):'<p class="dim">Chưa có sự kiện</p>';
}
async function send(kind,amount=1){try{const res=await fetch('/api/event',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:$('name').value||'Đạo Hữu',kind,amount})});const data=await res.json();$('result').textContent=data.ok?'✅ Đã xử lý '+kind:'❌ '+data.error;}catch(e){$('result').textContent='❌ Không thể kết nối server';}}
document.querySelectorAll('button[data-kind]').forEach(btn=>btn.onclick=()=>send(btn.dataset.kind,btn.dataset.kind==='heart'?10:1));
$('reset').onclick=async()=>{if(!confirm('Xóa toàn bộ tiến trình demo?'))return;await fetch('/api/reset',{method:'POST'});$('result').textContent='Đã đặt lại dữ liệu.'};
function connect(){const ws=new WebSocket((location.protocol==='https:'?'wss://':'ws://')+location.host+'/ws');ws.onopen=()=>{$('connection').textContent='Đã kết nối';$('dot').style.color='#62dc9b'};ws.onmessage=e=>{const m=JSON.parse(e.data);if(m.type==='state')draw(m.data)};ws.onclose=()=>{$('connection').textContent='Mất kết nối, đang thử lại';$('dot').style.color='#ff8a8a';setTimeout(connect,1800)};}
fetch('/api/state').then(r=>r.json()).then(draw).catch(()=>{});connect();
