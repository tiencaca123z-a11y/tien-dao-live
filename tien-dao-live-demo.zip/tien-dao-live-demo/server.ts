import { join } from 'node:path';
const PORT = 3000;
const SAVE_FILE = join(import.meta.dir, 'save.json');
const realmNames = ['Phàm Nhân','Luyện Khí','Trúc Cơ','Kim Đan','Nguyên Anh','Hóa Thần','Luyện Hư','Hợp Thể','Đại Thừa','Độ Kiếp','Chân Tiên'];
type Player = {name:string;xp:number;realm:number;stones:number;power:number;hits:number};
type Event = {name:string;kind:string;amount?:number;at:string};
type State = {players: Record<string,Player>; boss:{hp:number;maxHp:number;level:number};events:Event[];totalHearts:number};
let state: State = {players:{},boss:{hp:500,maxHp:500,level:1},events:[],totalHearts:0};
try {const file = Bun.file(SAVE_FILE);if(await file.exists()) state={...state,...await file.json()};}catch{console.warn('Không đọc được save.json; dùng dữ liệu mới.');}
let saveTimer: ReturnType<typeof setTimeout> | undefined;
function save(){clearTimeout(saveTimer);saveTimer=setTimeout(()=>Bun.write(SAVE_FILE,JSON.stringify(state,null,2)),300)}
function safeName(v:unknown):string {return String(v??'Đạo Hữu').trim().slice(0,24).replace(/[<>\\"']/g,'')||'Đạo Hữu'}
function getPlayer(raw:unknown){const name=safeName(raw);const key=name.toLocaleLowerCase('vi');return state.players[key]??(state.players[key]={name,xp:0,realm:0,stones:0,power:1,hits:0})}
function need(realm:number){return 100*(realm+1)**2}
function pushEvent(name:string,kind:string,amount?:number){state.events.unshift({name,kind,amount,at:new Date().toLocaleTimeString('vi-VN',{hour12:false})});state.events=state.events.slice(0,30)}
function apply(input:any){const name=safeName(input.name);const p=getPlayer(name);const kind=String(input.kind||'');const amount=Math.min(100,Math.max(1,Math.floor(Number(input.amount)||1)));
  switch(kind){
    case 'join':pushEvent(name,'gia nhập tiên giới');break;
    case 'heart': {const gain=amount*p.power*2;p.xp+=gain;state.totalHearts+=amount;pushEvent(name,'thả tim',amount);break;}
    case 'comment':p.xp+=10*p.power;pushEvent(name,'bình luận tu luyện');break;
    case 'gift': {const reward=amount*20;p.stones+=reward;pushEvent(name,'nhận quà mô phỏng',amount);break;}
    case 'fight': {const damage=10*p.power+5*p.realm;p.hits+=damage;state.boss.hp-=damage;pushEvent(name,'đánh boss',damage);
      if(state.boss.hp<=0){p.stones+=150*state.boss.level;const next=state.boss.level+1;state.boss={level:next,maxHp:500+next*300,hp:500+next*300};pushEvent('Hệ thống','boss bị hạ! Boss mới xuất hiện');}break;}
    case 'breakthrough': if(p.realm<realmNames.length-1 && p.xp>=need(p.realm)){p.xp-=need(p.realm);p.realm++;pushEvent(name,'đột phá '+realmNames[p.realm]);}else{pushEvent(name,'chưa đủ tu vi đột phá');}break;
    case 'upgrade': {const cost=p.power*50;if(p.stones>=cost){p.stones-=cost;p.power++;pushEvent(name,'nâng công pháp lên '+p.power);}else{pushEvent(name,'chưa đủ linh thạch');}break;}
    default:throw new Error('Sự kiện không hợp lệ');
  }
  save();broadcast();return p;
}
function snapshot(){return {players:Object.values(state.players).sort((a,b)=>b.realm-a.realm||b.xp-a.xp).slice(0,100),boss:state.boss,events:state.events,totalHearts:state.totalHearts,realms:realmNames};}
const clients=new Set<any>();
function broadcast(){const text=JSON.stringify({type:'state',data:snapshot()});for(const ws of clients){try{ws.send(text)}catch{clients.delete(ws)}}}
const server=Bun.serve({port:PORT,
 async fetch(req,server){const url=new URL(req.url);
  if(url.pathname==='/ws'){if(server.upgrade(req))return;return new Response('WebSocket unavailable',{status:400});}
  if(url.pathname==='/api/state')return Response.json(snapshot());
  if(url.pathname==='/api/event'&&req.method==='POST'){
    try{const body=await req.json();if(JSON.stringify(body).length>1000)throw new Error('Dữ liệu quá dài');const p=apply(body);return Response.json({ok:true,player:p});}
    catch(err:any){return Response.json({ok:false,error:err.message},{status:400});}
  }
  if(url.pathname==='/api/reset'&&req.method==='POST'){state={players:{},boss:{hp:500,maxHp:500,level:1},events:[],totalHearts:0};save();broadcast();return Response.json({ok:true});}
  const relative=url.pathname==='/'?'index.html':url.pathname.substring(1);
  if(!['index.html','style.css','app.js'].includes(relative))return new Response('Not found',{status:404});
  const file=Bun.file(join(import.meta.dir,'public',relative));if(!await file.exists())return new Response('Not found',{status:404});return new Response(file);
 }, websocket:{open(ws){clients.add(ws);ws.send(JSON.stringify({type:'state',data:snapshot()}));},close(ws){clients.delete(ws)},message(){}}
});
console.log(`☯ Game chạy tại http://localhost:${server.port}`);
